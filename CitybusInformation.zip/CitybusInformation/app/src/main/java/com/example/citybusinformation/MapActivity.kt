package com.example.citybusinformation

import RouteAdapter
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.database.*

class MapActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var spinnerRoutes: Spinner
    private lateinit var recyclerViewRoutes: RecyclerView
    private lateinit var routesList: MutableList<String>
    private lateinit var routeDetails: MutableMap<String, List<String>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Select Bus Route"

        spinnerRoutes = findViewById(R.id.spinnerRoutes)
        recyclerViewRoutes = findViewById(R.id.recyclerViewRoutes)

        routesList = mutableListOf("Select a route")
        routeDetails = mutableMapOf()

        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, routesList)
        spinnerRoutes.adapter = spinnerAdapter

        recyclerViewRoutes.layoutManager = LinearLayoutManager(this)
        recyclerViewRoutes.adapter = RouteAdapter(emptyList(), this)

        database = FirebaseDatabase.getInstance().reference.child("routes")
        fetchRoutesFromFirebase()

        spinnerRoutes.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedRoute = routesList[position]
                val selectedStops = routeDetails[selectedRoute] ?: emptyList()
                recyclerViewRoutes.adapter = RouteAdapter(selectedStops, this@MapActivity)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                recyclerViewRoutes.adapter = RouteAdapter(emptyList(), this@MapActivity)
            }
        }

        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.selectedItemId = R.id.nav_map

        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_journey -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    true
                }
                R.id.nav_map -> true
                R.id.nav_schedule -> {
                    startActivity(Intent(this, ScheduleActivity::class.java))
                    true
                }
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun fetchRoutesFromFirebase() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                routesList.clear()
                routesList.add("Select a route")
                routeDetails.clear()

                for (routeSnapshot in snapshot.children) {
                    val routeName = routeSnapshot.child("name").getValue(String::class.java) ?: "Unknown Route"
                    val stopsList = routeSnapshot.child("stops").children.map { it.getValue(String::class.java) ?: "" }
                    routesList.add(routeName)
                    routeDetails[routeName] = stopsList
                }

                runOnUiThread {
                    val spinnerAdapter = spinnerRoutes.adapter as? ArrayAdapter<String>
                    spinnerAdapter?.notifyDataSetChanged()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MapActivity, "Failed to load routes", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
