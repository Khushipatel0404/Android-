package com.example.citybusinformation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class StopsAdapter(private var stopsList: List<String>) :
    RecyclerView.Adapter<StopsAdapter.StopViewHolder>() {

    class StopViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewStopName: TextView = itemView.findViewById(R.id.textViewStopName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StopViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_stop, parent, false)
        return StopViewHolder(view)
    }

    override fun onBindViewHolder(holder: StopViewHolder, position: Int) {
        holder.textViewStopName.text = stopsList[position]
    }

    override fun getItemCount(): Int = stopsList.size

    // Function to update stops dynamically
    fun updateStops(newStops: List<String>) {
        stopsList = newStops
        notifyDataSetChanged()
    }
}
