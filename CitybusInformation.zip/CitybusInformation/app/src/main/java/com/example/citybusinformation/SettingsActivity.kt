package com.example.citybusinformation

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RatingBar
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class
SettingsActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var switchNotification: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // SharedPreferences for saving switch state
        sharedPreferences = getSharedPreferences("AppSettings", Context.MODE_PRIVATE)
        switchNotification = findViewById(R.id.switchNotification)

        // Load saved notification setting
        val isNotificationEnabled = sharedPreferences.getBoolean("NOTIFICATIONS_ENABLED", false)
        switchNotification.isChecked = isNotificationEnabled

        // Switch Change Listener for Notifications
        switchNotification.setOnCheckedChangeListener { _, isChecked ->
            val editor = sharedPreferences.edit()
            editor.putBoolean("NOTIFICATIONS_ENABLED", isChecked)
            editor.apply()

            if (isChecked) {
                Toast.makeText(this, "Notifications Enabled", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Notifications Disabled", Toast.LENGTH_SHORT).show()
            }
        }

        // Share App Functionality
        val btnShare = findViewById<Button>(R.id.btn_share)
        btnShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_TEXT, "Check out this app: https://play.google.com/store/apps/details?id=${packageName}")
            startActivity(Intent.createChooser(shareIntent, "Share via"))
        }

        // Rating Functionality
        val ratingBar: RatingBar = findViewById(R.id.ratingBar)
        ratingBar.setOnRatingBarChangeListener { _, rating, _ ->
            Toast.makeText(this, "You rated: $rating stars", Toast.LENGTH_SHORT).show()
            ratingBar.progressDrawable.setTint(Color.YELLOW)
        }
        val termsLayout = findViewById<LinearLayout>(R.id.termsConditionsLayout)

        termsLayout.setOnClickListener {
            val intent = Intent(this, TermsActivity::class.java)
            startActivity(intent)
        }
        // In your SettingsActivity


        // Bottom Navigation setup
        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.selectedItemId = R.id.nav_settings
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_journey -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    true
                }
                R.id.nav_map -> {
                    startActivity(Intent(this, MapActivity::class.java))
                    true
                }
                R.id.nav_schedule -> {
                    startActivity(Intent(this, ScheduleActivity::class.java))
                    true
                }
                R.id.nav_settings -> true
                else -> false
            }
        }
    }
}
