package com.example.citybusinformation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class NewRouteAdapter(private var routes: List<String>) :
    RecyclerView.Adapter<NewRouteAdapter.RouteViewHolder>() {

    class RouteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val txtRouteDetails: TextView = itemView.findViewById(R.id.txtRouteDetails)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RouteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_new_route, parent, false)
        return RouteViewHolder(view)
    }

    override fun onBindViewHolder(holder: RouteViewHolder, position: Int) {
        holder.txtRouteDetails.text = routes[position]
    }

    override fun getItemCount(): Int = routes.size

    fun updateData(newRoutes: List<String>) {
        routes = newRoutes
        notifyDataSetChanged()
    }
}
