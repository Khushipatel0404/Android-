package com.example.citybusinformation

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class TermsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terms) // सही XML फाइल लोड करें

        val termsTextView = findViewById<TextView>(R.id.termsTextView)
        termsTextView.text = """
1. Introduction

1.1 The BRTS Ahmedabad is licensed to you subject to the terms of the License Agreement.

2. Accepting this License Agreement

2.1 In order to use this application, you must first agree to the License Agreement. You may not use the application if you do not accept the License Agreement.

2.2 By clicking to accept, you hereby agree to the terms of the License Agreement.

3. Use of the application by You

3.1 You agree that you will not engage in any activity with the application, that interferes with, disrupts, damages, or accesses in an unauthorized manner.

3.2 All the data contained in this application, has been collected manually. You agree that you are solely responsible for any consequences of your actions (including any loss or damage) if any of the information provided in the application is found wrong.

4. Privacy and Information

4.1 In order to update user location application is accessing your current location. Before any of this information is collected, the SDK will notify you and seek your consent. If you withhold consent, the information will not be collected.

4.2 In order to continually innovate and improve the application, application may collect certain usage statistics from the software including but not limited to a unique identifier, associated IP address, version number of the software, and information on which devices and/or services in the application are being used and how they are being used.

4.3 The data collected is examined in the aggregate to improve the application and is maintained in accordance with Privacy Policy.            
 5. DISCLAIMER OF WARRANTIES

 5.1 YOU EXPRESSLY UNDERSTAND AND AGREE THAT YOUR USE OF THE APPLICATION IS AT YOUR SOLE RISK AND THAT THE APPLICATION IS PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTY OF ANY KIND FROM DEVELOPER.

 5.2 YOUR USE OF THE APPLICATION IS AT YOUR OWN DISCRETION AND RISK AND YOU ARE SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR MOBILE PHONE OR OTHER DEVICE OR LOSS OF DATA THAT RESULTS FROM SUCH USE.

 6. Changes to the License Agreement

 6.1 Developer may make changes to the License Agreement as it distributes new versions of the application. When these changes are made, developer will make a new version of the License Agreement available in the application.

 Note: This is not an official application of Janmarg.
        
            Thank you for using our app!
        """.trimIndent()
    }
}
