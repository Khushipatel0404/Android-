import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.citybusinformation.R

class RouteAdapter(private val stops: List<String>, private val context: Context) :
    RecyclerView.Adapter<RouteAdapter.RouteViewHolder>() {

    private val expandedPositions = mutableSetOf<Int>()

    private val busStopLocations = mapOf(
        "Ghuma Gam" to Pair(23.0261, 72.5150),
        "Little Wings" to Pair(23.0240, 72.5200),
        "Bopal Gam" to Pair(23.0255, 72.5300),
        "Sterling City" to Pair(23.0275, 72.5350),
        "Bhavya Park" to Pair(23.0285, 72.5400),
        "Samarpan Bunglows" to Pair(23.0295, 72.5455),
        "Bopal Approach" to Pair(23.0300, 72.5500),
        "Ambali Gam" to Pair(23.0310, 72.5550),
        "Swagat Bunglows" to Pair(23.0320, 72.5600),
        "Jayantilal Park" to Pair(23.0330, 72.5650),
        "Ashok Vatika" to Pair(23.0340, 72.5700),
        "Antariksh Colony" to Pair(23.0350, 72.5750),
        "Iskon Mandir" to Pair(23.0360, 72.5800),
        "Iskon Cross Road" to Pair(23.0370, 72.5850),
        "Ramdevnagar" to Pair(23.0380, 72.5900),
        "Isro" to Pair(23.0390, 72.5950),
        "Star Bazaar" to Pair(23.0400, 72.6000),
        "Jodhpur Char rasta" to Pair(23.0410, 72.6050),
        "Shivranjani" to Pair(23.0260, 72.5450),
        "Jhasi Ki Raani" to Pair(23.0420, 72.6100),
        "NehruNagar" to Pair(23.0430, 72.6150),
        "ManekBagh" to Pair(23.0440, 72.6200),
        "Dharnidhar Derasar" to Pair(23.0450, 72.6250),
        "Anjali" to Pair(23.0460, 72.6300),
        "Chandranagar" to Pair(23.0470, 72.6350),
        "KhodiyarNagar" to Pair(23.0480, 72.6400),
        "Danilimda Char Rasta" to Pair(23.0165, 72.5714),
        "Vaikunth Dham Mandir" to Pair(23.0500, 72.6500),
        "Swaminarayan Collage" to Pair(23.0510, 72.6550),
        "Kankariya Telephone Exchange" to Pair(23.0520, 72.6600),
        "Kakariya Lake Shukla Dada Chowk" to Pair(23.0530, 72.6650),
        "Rambaug" to Pair(23.0540, 72.6700),
        "Maninagar Char Rasta" to Pair(23.0550, 72.6750),
        "Maninagar Railway" to Pair(22.9920, 72.6010)

    )

    private val busStopTimings = mapOf(
        "Ghuma Gam" to mapOf(
            "Morning" to listOf("8:00 AM", "9:05 AM", "10:10 AM", "11:15 AM"),
            "Evening" to listOf("5:00 PM", "6:05 PM", "7:10 PM", "8:15 PM")
        ),
        "Little Wings" to mapOf(
            "Morning" to listOf("8:05 AM", "9:10 AM", "10:15 AM", "11:20 AM"),
            "Evening" to listOf("5:05 PM", "6:10 PM", "7:15 PM", "8:20 PM")
        ),
        "Bopal Gam" to mapOf(
            "Morning" to listOf("8:10 AM", "9:15 AM", "10:20 AM", "11:25 AM"),
            "Evening" to listOf("5:10 PM", "6:15 PM", "7:20 PM", "8:25 PM")
        ),
        "Sterling City" to mapOf(
            "Morning" to listOf("8:15 AM", "9:20 AM", "10:25 AM", "11:30 AM"),
            "Evening" to listOf("5:15 PM", "6:20 PM", "7:25 PM", "8:30 PM")
        ),
        "Bhavya Park" to mapOf(
            "Morning" to listOf("8:20 AM", "9:25 AM", "10:30 AM", "11:35 AM"),
            "Evening" to listOf("5:20 PM", "6:25 PM", "7:30 PM", "8:35 PM")
        ),
        "Samarpan Bunglows" to mapOf(
            "Morning" to listOf("8:25 AM", "8:30 AM", "8:35 AM", "8:40 AM"),
            "Evening" to listOf("5:25 PM", "5:30 PM", "5:35 PM", "5:40 PM")
        ),
        "Bopal Approach" to mapOf(
            "Morning" to listOf("8:30 AM", "8:35 AM", "8:40 AM", "8:45 AM"),
            "Evening" to listOf("5:30 PM", "5:35 PM", "5:40 PM", "5:45 PM")
        ),
        "Ambali Gam" to mapOf(
            "Morning" to listOf("8:35 AM", "8:40 AM", "8:45 AM", "8:50 AM"),
            "Evening" to listOf("5:35 PM", "5:40 PM", "5:45 PM", "5:50 PM")
        ),
        "Swagat Bunglows" to mapOf(
            "Morning" to listOf("8:40 AM", "8:45 AM", "8:50 AM", "8:55 AM"),
            "Evening" to listOf("5:40 PM", "5:45 PM", "5:50 PM", "5:55 PM")
        )
    )


    class RouteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val stopName: TextView = view.findViewById(R.id.textViewStopName)
        val stopIcon: ImageView = view.findViewById(R.id.imageViewStopIcon)
        val arrowIcon: ImageView = view.findViewById(R.id.imageViewArrow)
        val expandableView: View = view.findViewById(R.id.layoutTimings)
        val timingsTextView: TextView = view.findViewById(R.id.textViewBusTimings)
        val clockIcon: ImageView = view.findViewById(R.id.imageViewClock)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RouteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_stop, parent, false)
        return RouteViewHolder(view)
    }

    override fun onBindViewHolder(holder: RouteViewHolder, position: Int) {
        val stopName = stops[position]
        holder.stopName.text = stopName

        // Set Bus Stop Icon Based on Position
        when (position) {
            0 -> holder.stopIcon.setImageResource(R.drawable.ic_bus_start)  // First stop
            stops.size - 1 -> holder.stopIcon.setImageResource(R.drawable.ic_bus_end)  // Last stop
            else -> holder.stopIcon.setImageResource(R.drawable.ic_bus_stop)  // Middle stops
        }

        val isExpanded = expandedPositions.contains(position)
        holder.expandableView.visibility = if (isExpanded) View.VISIBLE else View.GONE
        holder.arrowIcon.setImageResource(if (isExpanded) R.drawable.ic_arrow_right else R.drawable.ic_arrow_right)

        holder.stopName.setOnClickListener {
            if (isExpanded) {
                expandedPositions.remove(position)
            } else {
                expandedPositions.add(position)
            }
            notifyItemChanged(position)
        }

        holder.arrowIcon.setOnClickListener { checkLocationAndOpenMaps(stopName) }

        val morningTimings = busStopTimings[stopName]?.get("Morning")?.joinToString(", ") ?: "No timings available"
        val eveningTimings = busStopTimings[stopName]?.get("Evening")?.joinToString(", ") ?: "No timings available"

        holder.timingsTextView.text = "Morning: $morningTimings\nEvening: $eveningTimings"

    }

    override fun getItemCount(): Int = stops.size

    private fun checkLocationAndOpenMaps(stopName: String) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {

            if (context is Activity) {
                ActivityCompat.requestPermissions(
                    context,
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                    1001
                )
            } else {
                Toast.makeText(context, "Permission required", Toast.LENGTH_SHORT).show()
            }
        } else {
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                Toast.makeText(context, "Please enable location services", Toast.LENGTH_LONG).show()
                context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            } else {
                openGoogleMaps(stopName)
            }
        }
    }

    private fun openGoogleMaps(stopName: String) {
        busStopLocations[stopName]?.let { (lat, lng) ->
            val gmmIntentUri = Uri.parse("geo:$lat,$lng?q=$stopName Bus Stop")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
                setPackage("com.google.android.apps.maps")
            }
            context.startActivity(mapIntent)
        }
    }
}
