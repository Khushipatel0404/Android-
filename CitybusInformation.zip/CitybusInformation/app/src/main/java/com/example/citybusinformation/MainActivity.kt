package com.example.citybusinformation

import android.content.Intent
import android.os.Bundle
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import android.graphics.PorterDuff
import android.os.Build

class MainActivity : AppCompatActivity() {

    private lateinit var spinnerFrom: Spinner
    private lateinit var spinnerTo: Spinner
    private lateinit var btnSearch: Button
    private lateinit var recyclerViewRoutes: RecyclerView
    private lateinit var routeAdapter: NewRouteAdapter
    private lateinit var progressBar: ProgressBar
    private lateinit var database: DatabaseReference
    private lateinit var btnMenu: ImageView
    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var txtUserEmail: TextView

    private val routesWithStops = mutableMapOf<String, List<String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinnerFrom = findViewById(R.id.spinnerFrom)
        spinnerTo = findViewById(R.id.spinnerTo)
        btnSearch = findViewById(R.id.btnSearch)
        recyclerViewRoutes = findViewById(R.id.recyclerViewRoutes)
        progressBar = findViewById(R.id.progressBar)
        btnMenu = findViewById(R.id.btnMenu)
        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        txtUserEmail = findViewById(R.id.txtUserEmail)

        // Display logged-in user's email
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser != null) {
            txtUserEmail.text = "Logged in as: ${currentUser.email}"
            txtUserEmail.visibility = View.VISIBLE
        } else {
            txtUserEmail.visibility = View.GONE
        }

        // RecyclerView setup
        recyclerViewRoutes.layoutManager = LinearLayoutManager(this)
        routeAdapter = NewRouteAdapter(emptyList())
        recyclerViewRoutes.adapter = routeAdapter

        // Initialize Firebase
        database = FirebaseDatabase.getInstance().reference.child("routes")

        // Load routes data from Firebase
        fetchRoutesFromFirebase()

        // Search Button Click
        btnSearch.setOnClickListener { searchRoute() }

        // Show PopupMenu on Menu Icon Click
        btnMenu.setOnClickListener { view ->
            showPopupMenu(view)
        }

        // Bottom Navigation Click Listener
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_journey -> true
                R.id.nav_map -> {
                    startActivity(Intent(this, MapActivity::class.java))
                    true
                }
                R.id.nav_schedule -> {
                    startActivity(Intent(this, ScheduleActivity::class.java))
                    true
                }
                R.id.nav_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                else -> false
            }
        }


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            progressBar.indeterminateDrawable.setColorFilter(
                ContextCompat.getColor(this, R.color.primaryColor),
                PorterDuff.Mode.SRC_IN
            )
        }
    }

    // Function to Show PopupMenu
    private fun showPopupMenu(view: View) {
        val popup = PopupMenu(this, view)
        val inflater: MenuInflater = popup.menuInflater
        inflater.inflate(R.menu.menu_main, popup.menu)

        popup.setOnMenuItemClickListener { item: MenuItem ->
            when (item.itemId) {

//                R.id.menu_logout -> {
//                    FirebaseAuth.getInstance().signOut()  // Logout user
//                    txtUserEmail.visibility = View.GONE   // Email hide karenge
//                    Toast.makeText(this, "Logged Out", Toast.LENGTH_SHORT).show()
//
//                    startActivity(Intent(this, LoginActivity::class.java))
//                    finish()
//                    true
//                }
                R.id.menu_logout -> {
                    val auth = FirebaseAuth.getInstance()
                    auth.signOut()  // Logout user

                    // Clear SharedPreferences
                    val sharedPreferences = getSharedPreferences("UserSession", MODE_PRIVATE)
                    sharedPreferences.edit().clear().apply()

                    txtUserEmail.visibility = View.GONE  // Email hide karein
                    Toast.makeText(this, "Logged Out Successfully", Toast.LENGTH_SHORT).show()

                    // Redirect to Login Page
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                    true
                }

                R.id.menu_change_password -> {
                    startActivity(Intent(this, ChangePasswordActivity::class.java))
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    // Fetch routes from Firebase
    private fun fetchRoutesFromFirebase() {
        progressBar.visibility = View.VISIBLE

        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                progressBar.visibility = View.GONE

                if (!snapshot.exists()) {
                    Toast.makeText(this@MainActivity, "No route data found", Toast.LENGTH_SHORT).show()
                    return
                }

                val stopsSet = mutableSetOf<String>()

                for (routeSnapshot in snapshot.children) {
                    val routeName = routeSnapshot.child("name").value?.toString() ?: continue
                    val stopsList = routeSnapshot.child("stops").children.mapNotNull { it.value?.toString() }

                    routesWithStops[routeName] = stopsList
                    stopsSet.addAll(stopsList)
                }

                val stopsArray = listOf("Select bus stop") + stopsSet.sorted()
                val adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, stopsArray)

                spinnerFrom.adapter = adapter
                spinnerTo.adapter = adapter
            }

            override fun onCancelled(error: DatabaseError) {
                progressBar.visibility = View.GONE
                Toast.makeText(this@MainActivity, "Failed to load routes", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Search Functionality
    private fun searchRoute() {
        val from = spinnerFrom.selectedItem.toString()
        val to = spinnerTo.selectedItem.toString()

        if (from == "Select bus stop" || to == "Select bus stop") {
            Toast.makeText(this, "Please select both stops", Toast.LENGTH_SHORT).show()
            return
        }

        val routeInfo = mutableListOf<String>()

        for ((route, stops) in routesWithStops) {
            val fromIndex = stops.indexOf(from)
            val toIndex = stops.indexOf(to)

            if (fromIndex in 0 until toIndex) {
                val intermediateStops = stops.subList(fromIndex + 1, toIndex)
                val formattedStops = intermediateStops.joinToString(" → ").ifEmpty { "No stops in between" }

                routeInfo.add("🚍 **$route**\nStops in between: $formattedStops")
            }
        }

        if (routeInfo.isEmpty()) {
            routeInfo.add("❌ No direct route found between $from and $to")
        }

        routeAdapter.updateData(routeInfo)
    }
}